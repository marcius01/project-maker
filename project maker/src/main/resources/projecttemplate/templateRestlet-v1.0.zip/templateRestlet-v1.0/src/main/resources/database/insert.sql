BEGIN TRANSACTION;

insert into hibernate_sequences values('Bean1', 1);
insert into hibernate_sequences values('Bean2', 1);

COMMIT;