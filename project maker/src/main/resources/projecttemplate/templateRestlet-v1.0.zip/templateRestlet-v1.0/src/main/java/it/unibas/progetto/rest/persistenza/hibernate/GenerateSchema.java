package it.unibas.progetto.rest.persistenza.hibernate;

import java.io.File;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.slf4j.LoggerFactory;

public class GenerateSchema {

    private final static org.slf4j.Logger logger = LoggerFactory.getLogger(GenerateSchema.class);

    public static void main(String[] args) {
        new GenerateSchema().createSchemaWithHibernate4();
        System.exit(0);
    }

    public void createSchemaWithHibernate4() {
        Configuration cfg = new Configuration();
        cfg.configure();
        SchemaExport schemaExport = new SchemaExport(cfg);
        schemaExport.setFormat(true);
        schemaExport.setHaltOnError(true);
        schemaExport.setDelimiter(";");
        File schemaOutputFile = new File("src/main/resources/database/schema.sql");
        if (schemaOutputFile.exists()) {
            schemaOutputFile.delete();
        }
        schemaExport.setOutputFile(schemaOutputFile.toString());
        schemaExport.execute(true, false, false, true);
    }

}
