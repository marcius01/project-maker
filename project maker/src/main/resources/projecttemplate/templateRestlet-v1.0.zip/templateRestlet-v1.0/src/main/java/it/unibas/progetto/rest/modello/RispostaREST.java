package it.unibas.progetto.rest.modello;

public class RispostaREST {

    private Object risultato;
    private boolean successo;

    public RispostaREST() {
    }

    public RispostaREST(Object risultato, boolean successo) {
        this.risultato = risultato;
        this.successo = successo;
    }

    public boolean isSuccesso() {
        return successo;
    }

    public void setSuccesso(boolean successo) {
        this.successo = successo;
    }

    public Object getRisultato() {
        return risultato;
    }

    public void setRisultato(Object risultato) {
        this.risultato = risultato;
    }

}
