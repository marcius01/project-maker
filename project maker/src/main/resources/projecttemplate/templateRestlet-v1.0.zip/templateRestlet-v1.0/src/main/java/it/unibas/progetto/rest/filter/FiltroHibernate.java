package it.unibas.progetto.rest.filter;

import it.unibas.progetto.rest.persistenza.hibernate.DAOUtilHibernate;
import it.unibas.progetto.rest.utility.RestUtility;
import org.hibernate.StaleObjectStateException;
import org.restlet.Context;
import org.restlet.Request;
import org.restlet.Response;
import org.restlet.Restlet;
import org.restlet.data.Status;
import org.restlet.resource.ResourceException;
import org.restlet.routing.Filter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FiltroHibernate extends Filter {

    private Logger logger = LoggerFactory.getLogger(FiltroHibernate.class);

    public FiltroHibernate() {
    }

    public FiltroHibernate(Context context) {
        super(context);
    }

    public FiltroHibernate(Context context, Restlet next) {
        super(context, next);
    }

    @Override
    protected int beforeHandle(Request request, Response response) {
        try {
            logger.info("Inizio una transazione sul DB");
            DAOUtilHibernate.getSessionFactory().getCurrentSession().beginTransaction();
        } catch (StaleObjectStateException staleEx) {
            logger.error("Questo filtro non implementa una strategia di locking ottimistico!");
            logger.error("In caso di errore, e' necessario introdurre qui la logica applicativa per gestirlo!");
            response.setStatus(Status.SERVER_ERROR_INTERNAL, staleEx.getMessage());
            return Filter.STOP;
        } catch (Throwable ex) {
            logger.error("Eccezione catturata nel FiltroHibernate: {}", ex.getMessage(), ex);
            try {
                if (DAOUtilHibernate.getSessionFactory().getCurrentSession().getTransaction().isActive()) {
                    logger.debug("Provo a fare il rollback della transazione a seguito di un'eccezione");
                    DAOUtilHibernate.getSessionFactory().getCurrentSession().getTransaction().rollback();
                }
            } catch (Throwable rbEx) {
                logger.error("Impossibile effettuare il rollback a seguito dell'eccezione!", rbEx);
            }
            response.setStatus(Status.SERVER_ERROR_INTERNAL, ex.getMessage());
            return Filter.STOP;
        }
        return super.beforeHandle(request, response);
    }

    @Override
    protected void afterHandle(Request request, Response response) {
        try {
            logger.info("Effettuo il commit di una transazione sul DB");
            if (DAOUtilHibernate.getSessionFactory().getCurrentSession().getTransaction().isActive()) {
                DAOUtilHibernate.getSessionFactory().getCurrentSession().getTransaction().commit();
            }
        } catch (StaleObjectStateException staleEx) {
            logger.error("Questo filtro non implementa una strategia di locking ottimistico!");
            logger.error("In caso di errore, e' necessario introdurre qui la logica applicativa per gestirlo!");
            response.setStatus(Status.SERVER_ERROR_INTERNAL, staleEx.getMessage());
            throw staleEx;
        } catch (Throwable ex) {
            logger.error("Eccezione catturata nel FiltroHibernate: {}", ex.getMessage(), ex);
            try {
                if (DAOUtilHibernate.getSessionFactory().getCurrentSession().getTransaction().isActive()) {
                    logger.debug("Provo a fare il rollback della transazione a seguito di un'eccezione");
                    DAOUtilHibernate.getSessionFactory().getCurrentSession().getTransaction().rollback();
                }
            } catch (Throwable rbEx) {
                logger.error("Impossibile effettuare il rollback a seguito dell'eccezione!", rbEx);
            }
            response.setStatus(Status.SERVER_ERROR_INTERNAL, ex.getMessage());
            response.setEntity(RestUtility.printError(ex.getMessage()));
            throw new ResourceException(ex);
        }
        super.afterHandle(request, response);
    }

}
