package it.unibas.progetto.rest.utility;

import it.unibas.progetto.rest.modello.RispostaREST;
import it.unibas.progetto.rest.persistenza.DAOGenericoJson;
import java.util.ArrayList;
import java.util.List;
import org.dozer.Mapper;
import org.restlet.Request;
import org.restlet.data.CharacterSet;
import org.restlet.data.Form;
import org.restlet.data.MediaType;
import org.restlet.representation.Representation;
import org.restlet.representation.StringRepresentation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestUtility {

    private static Logger logger = LoggerFactory.getLogger(RestUtility.class);

    private static DAOGenericoJson daoGson = new DAOGenericoJson();

    public static Representation printResponse(Object object) {
        try {
            String response = daoGson.toJson(new RispostaREST(object, true));
            Representation representation = new StringRepresentation(response, MediaType.APPLICATION_JSON);
            representation.setCharacterSet(CharacterSet.UTF_8);
            return representation;
        } catch (Exception e) {
            return printError(e.getLocalizedMessage());
        }
    }

    public static Representation printError(Object error) {
        String response = daoGson.toJson(new RispostaREST(error, false));
        Representation representation = new StringRepresentation(response, MediaType.APPLICATION_JSON);
        representation.setCharacterSet(CharacterSet.UTF_8);
        return representation;
    }

    public static String getQueryValue(Request request, String name) {
        String result = null;
        Form query = request.getResourceRef().getQueryAsForm();

        if (query != null) {
            result = query.getFirstValue(name);
        }

        return result;
    }
    
    public static <T, U> List<U> map(final Mapper mapper, final List<T> source, final Class<U> destType) {
        List<U> dest = new ArrayList<U>();
        for (T element : source) {
            if (element == null) {
                continue;
            }
            dest.add(mapper.map(element, destType));
        }
        return dest;
    }

}
